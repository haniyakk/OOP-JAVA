package time;

import java.time.LocalDateTime;

public class Time {
    // Instance variables
    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;
    private int second;

    // Default Constructor
    public Time() {
        LocalDateTime currentDateTime = LocalDateTime.now();
        this.year = currentDateTime.getYear();
        this.month = currentDateTime.getMonthValue();
        this.day = currentDateTime.getDayOfMonth();
        this.hour = currentDateTime.getHour();
        this.minute = currentDateTime.getMinute();
        this.second = currentDateTime.getSecond();
    }

    // Overloaded Constructor 1 (Year, Month, Day)
    public Time(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = 0; // Default value
        this.minute = 0; // Default value
        this.second = 0; // Default value
    }

    // Overloaded Constructor 2 (Year, Month, Day, Hour, Minute, Second)
    public Time(int year, int month, int day, int hour, int minute, int second) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    // Method to get all values as an array
    public int[] getDateTime() {
        return new int[]{year, month, day, hour, minute, second};
    }

    // Method to set all values at once
    public void setDateTime(int year, int month, int day, int hour, int minute, int second) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    // Method to display date and time
    public void displayDateTime() {
        System.out.printf("Date and Time: %04d-%02d-%02d %02d:%02d:%02d%n",
                year, month, day, hour, minute, second);
    }

    public static void main(String[] args) {
        // Using the default constructor
        Time defaultTime = new Time();
        defaultTime.displayDateTime(); // Displaying the current date and time

        // Using the overloaded constructor for Year, Month, Day utilizing constructor 
        Time specificDate = new Time(2023, 10, 12);
        specificDate.displayDateTime(); // Displaying the specific date with default time

        // Using the overloaded constructor for Year, Month, Day, Hour, Minute, Second showing flexibility of code
        Time specificDateTime = new Time(2023, 10, 12, 15, 30, 45);
        specificDateTime.displayDateTime(); // Displaying the specific date and time

        // Using the setDateTime method to update values
        specificDateTime.setDateTime(2024, 12, 25, 10, 45, 30);
        specificDateTime.displayDateTime(); // Displaying updated date and time

        // Using the getDateTime method
        int[] dateTimeValues = specificDateTime.getDateTime();
        System.out.printf("Extracted Values: Year: %d, Month: %d, Day: %d, Hour: %d, Minute: %d, Second: %d%n",
                dateTimeValues[0], dateTimeValues[1], dateTimeValues[2], dateTimeValues[3], dateTimeValues[4], dateTimeValues[5]);
    }
}
