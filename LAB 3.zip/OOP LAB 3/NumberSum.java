package numbersum;
public class NumberSum {
    public static void main(String[] args) {

    }
    
}
