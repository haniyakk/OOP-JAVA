package first_exercise;

public class First_Exercise {

    public static void main(String[] args) {
        System.out.println("This is my first program.");
    }
}
