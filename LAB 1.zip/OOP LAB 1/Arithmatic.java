package arithmatic;
import java.util.Scanner;
public class Arithmatic{
    int num1,num2,sum,subt,product;
    public static void main(String[] args) {
        Arithmatic obj = new Arithmatic();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your first number: ");
        obj.num1 = sc.nextInt();
        System.out.print("Enter your second number: ");
        obj.num2 = sc.nextInt();
        obj.sum= obj.num1+obj.num2;
        obj.subt=obj.num1-obj.num2;
        obj.product=obj.num1*obj.num2;
        System.out.println("The sum of these numbers is: "+obj.sum);
        System.out.println("The subtraction of these numbers is: "+obj.subt);
        System.out.println("The product of these numbers is: "+obj.product);
    }
}
