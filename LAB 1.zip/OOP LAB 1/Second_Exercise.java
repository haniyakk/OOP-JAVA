package second_exercise;

public class Second_Exercise {
        public static void main(String[] args) {
        System.out.println("Name: HANIYA KHAN");
        System.out.println("Enrollment : 02-134241-019");
        System.out.println("Subject : OOP LAB");
        System.out.println("Instructor : SIR USMAN");
        System.out.println("Semester : SECOND");       
        }
}
