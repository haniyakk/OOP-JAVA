package mosque;

public class Mosque {
    public static void main(String[] args) {
      System.out.println("         ^           ^           ^   "); 
      System.out.println("       //|\\        //|\\        //|\\   "); 
      System.out.println("      (((&)))     (((^)))     (((&))) "); 
      System.out.println("        |.|         |.|         |.| ");
      System.out.println("        |.|         |.|         |.| "); 
      System.out.println("        |.|         |.|         |.| "); 
      System.out.println("        |.|         |.|         |.| "); 
      System.out.println("        |.|         |.|         |.| "); 
      System.out.println(" {'''''''''''''''''''''''''''''''''''''''} "); 
      System.out.println(" '||'''''''''''''''''''''''''''''''''||' "); 
      System.out.println("  ||                                 || "); 
      System.out.println("  ||                 _               || "); 
      System.out.println("  ||                {#}              || "); 
      System.out.println("  ||              {#####             || "); 
      System.out.println("  ||             {#######}           || "); 
      System.out.println("  ||             {#######}           || "); 
      System.out.println("  ||             {#######}           || "); 
      System.out.println("  ||             {#######}           || "); 
      System.out.println("  ||             {#######}           || "); 
      System.out.println(" (@@@@@@@@@@@@@@===========@@@@@@@@@@@@@@) "); 
      System.out.println(" (++++++++++++//=============\\+++++++++++) "); 
      System.out.println(" [%%%%%%%%%%%//===============\\%%%%%%%%%%%]"); 
      System.out.println(" '''''''''''//=================\\'''''''''''"); 
      System.out.println("           //===================\\          ");
    } 
}